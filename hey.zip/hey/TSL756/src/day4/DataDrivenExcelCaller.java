package day4;
import util.DataDrivenExcel;

public class DataDrivenExcelCaller {

	public static void main(String[] args) {
		DataDrivenExcel caller = new DataDrivenExcel("C:\\Users\\vshadmin\\Desktop\\dataDriven.xlsx");
		System.out.println(caller.rowCount("Sheet1"));
		System.out.println(caller.cellCount("Sheet1", 1));
		System.out.println(caller.Read("Sheet1", 1, 1));
		System.out.println(caller.Read("Sheet1", 2, 1));
	}
}
