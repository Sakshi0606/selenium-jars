package TestNGDay12March;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import util.Base;

public class ScrollingDemo extends Base{
	//WebDriver driver;
  @Test
  public void f() throws InterruptedException {
	  JavascriptExecutor js=(JavascriptExecutor)driver;
	  driver.get("http://seleniumhq.org");
	  
	  js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.linkText("Selenium blog")));
	  Thread.sleep(4000);
	  js.executeScript("window.scrollBy(0,-150)");// pixel by pixel
	  Thread.sleep(4000);
			  
	  js.executeScript("window.scrollBy(0,document.body.scrollHeight)");//scroll down to bottom
	  Thread.sleep(4000);
	  js.executeScript("window.scrollBy(0,-document.body.scrollHeight)");//scroll up to top
	  Thread.sleep(4000);
	  
  }
  
}
