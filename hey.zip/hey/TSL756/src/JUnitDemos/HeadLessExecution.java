package JUnitDemos;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class HeadLessExecution {
	static WebDriver driver;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{
		//driver=new HtmlUnitDriver(true);
		System.setProperty("webdriver.gecko.driver",".\\Drivers\\geckodriver.exe");
		FirefoxOptions op =new FirefoxOptions();
		op.addArguments("--headless");
		op.addArguments("----start- maximized");
		driver=new FirefoxDriver(op);

		//driver.manage().window().maximize();
		
		
		
	}

	

	@Test
	public void test() {
		driver.get("http://seleniumhq.org");
		driver.findElement(By.xpath("//a[text()='Download']")).click();
	 assertEquals("Downloads", driver.getTitle());
	assertTrue(driver.findElement(By.linkText("Maven users")).isDisplayed());
		
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception
	{
		driver.quit();
	}
}
